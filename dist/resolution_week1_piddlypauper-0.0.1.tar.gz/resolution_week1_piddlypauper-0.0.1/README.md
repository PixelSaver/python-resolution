# Resolution

For now, just week one: CLI done

